# Arati Kitchen
GitHub Pages ready website.
Menu: Egg Biryani ₹120, Kabuli Chana Masala ₹60, Palak Paneer ₹80, Matar Paneer ₹80, Tawa Roti ₹5, Green Moong with Egg Tadka ₹80, Plain Tadka ₹50.
Includes menu images, online order form, WhatsApp confirmation, payment selection, order ID tracking, Baranagar location, 9 AM–9 PM timing.
