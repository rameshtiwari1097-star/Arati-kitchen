ARATI KITCHEN — FIREBASE AUTOMATIC ORDER TRACKING
====================================================

Included:
1. customer.html  - customer enters Order ID and sees real-time status + delivery location
2. admin.html     - admin login and buttons:
   Order Accepted -> Preparing Food -> Ready for Delivery -> Out for Delivery -> Delivered
3. driver.html    - delivery partner login + GPS location sharing
4. firebase-config.js - paste Firebase Web App config here
5. firebase-common.js - Firebase initialization
6. database.rules.json - safer database rules
7. style.css - Arati Kitchen styling

SETUP (one time)
----------------
A) Firebase Console:
- Create a Firebase project.
- Add a Web App and copy its config into firebase-config.js.
- Create Realtime Database.
- Enable Authentication:
  * Anonymous (for customers)
  * Email/Password (for admin and delivery accounts)
- Create one admin Email/Password user.
- Create one delivery Email/Password user.

B) Add admin UID:
In Realtime Database, create:
staff
  admins
    YOUR_ADMIN_UID: true

The admin UID is visible after login or in Firebase Authentication -> Users.

C) Deploy:
Upload all files to the same Netlify site/folder.
Your customer tracking page can be:
https://YOUR-SITE.netlify.app/customer.html
Admin:
https://YOUR-SITE.netlify.app/admin.html
Delivery:
https://YOUR-SITE.netlify.app/driver.html

D) Assign driver:
1. Delivery partner logs into driver.html.
2. Copy the Firebase UID shown there.
3. Admin enters that UID against the Order ID.
4. Customer can then see the driver's latest GPS location.

IMPORTANT SECURITY
------------------
Do NOT make the Realtime Database public. Use the supplied rules and Firebase Authentication.
GPS is shared only after the delivery partner presses "Start Live Location" and grants browser location permission.
The customer page shows the latest GPS point; a full live map marker can be added later with Google Maps/Mapbox if desired.

The Firebase browser config is not a password/secret, but database rules and authentication must be configured correctly.
